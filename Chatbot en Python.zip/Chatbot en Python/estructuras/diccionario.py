diccionario = {
    "jas": 22,
    "luisa": 26,
    "verónica": 22
}

print(diccionario["jas"])
print(diccionario.get('jas1'))

for clave in diccionario.keys():
    print(clave)

for valor in diccionario.values():
    print(valor)    

for clave, valor in diccionario.items():
    print(f'{clave}: {valor}')        