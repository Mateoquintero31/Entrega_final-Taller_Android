mi_lista = [3, 15, 4, 8, 2, -1, -5]
mi_lista.append(22)
mi_lista.reverse()
print(mi_lista)

print(mi_lista.pop(3))
mi_lista.sort()

for valor in mi_lista:
    print(valor)

print(mi_lista)
mi_lista = []

mi_lista.clear()