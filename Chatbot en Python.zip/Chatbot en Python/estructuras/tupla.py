def mostrar():
    tuple = (1, 3, 6)
    num1, num2, num3 = tuple
    print(num1)
    print(num2)
    print(num3)
    print(type(tuple))