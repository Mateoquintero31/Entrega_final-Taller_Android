conjunto = {2,3,4,5,2}

print(conjunto)
print(type(conjunto))