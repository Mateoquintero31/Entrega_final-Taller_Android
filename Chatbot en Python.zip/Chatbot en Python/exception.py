def dividir(a, b):
    try:
        return a/b
    except:
        print('Error de división por 0')
        return 0


resultado = dividir(3,6)
print(resultado)