import pyodbc

direccion_servidor = '127.0.0.1'
nombre_bd = 'Encuesta'
nombre_usuario = 'encuesta'
password = 'encuesta'

try:
    conexion = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER=' + direccion_servidor+';DATABASE='+nombre_bd+';UID='+ nombre_usuario +';PWD=' + password)
    print('Conexión exitosa')
except:

    print('Error en la conexión')
