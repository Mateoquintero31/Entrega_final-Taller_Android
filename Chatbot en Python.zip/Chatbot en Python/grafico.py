from logging import exception
import matplotlib.pyplot as plt
from conexion.conexionSQLServer import conexion

try:
    cursor = conexion.cursor()

    #Obtenemos los datos
    cursor.execute("SELECT year(FechaNacimiento) Año, COUNT(1) Cantidad from Pacientes group by year(FechaNacimiento)")

    result = cursor.fetchall

    años = []
    cantidades = []

    for registro in cursor:
        años.append(registro[0])
        cantidades.append(registro[1])

    plt.bar(años, cantidades)
    plt.ylim(0,5)
    plt.xlabel("Año de Nacimiento")
    plt.ylabel("Cantidad")
    plt.title("Cantidad de Pacientes por año")
    plt.show()
except Exception as e:
    print("Error: ", e)
finally:
    conexion.close()