package com.example.dass_21;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.dass_21.Repositorio.UsuarioRepositorio;
import com.example.dass_21.api.ServicioUsuario;
import com.example.dass_21.api.UtilidadesApi;
import com.example.dass_21.modelos.Usuario;

import java.util.Calendar;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class IngresarDatos extends AppCompatActivity {

    private Spinner spinner1;
    TextView tv, efecha, txtEstadoCivil;
    RadioButton r1, r2, radioButtonMasculino;
    private EditText txtNombreCompleto, txtNumeroIdentificacion, TxtEdad, txtDireccionResidencia, txtCiudadResidencia,
            TxtTelefonoContacto, txtOcupacion, txtEPS, TxtEmail, TxtContactoEmergencia;
    RadioGroup rgGenero;
    private Button btnGuardar;
    private UsuarioRepositorio repositorio;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ingresar_datos);

        txtNombreCompleto = (EditText) findViewById(R.id.txtNombreCompleto);
        txtNumeroIdentificacion = (EditText) findViewById(R.id.txtNumeroIdentificacion);
        TxtEdad = (EditText) findViewById(R.id.TxtEdad);
        txtDireccionResidencia = (EditText) findViewById(R.id.txtDireccionResidencia);
        txtCiudadResidencia = (EditText) findViewById(R.id.txtCiudadResidencia);
        TxtTelefonoContacto = (EditText) findViewById(R.id.TxtTelefonoContacto);
        txtOcupacion = (EditText) findViewById(R.id.txtOcupacion);
        txtEPS = (EditText) findViewById(R.id.txtEPS);
        TxtEmail = (EditText) findViewById(R.id.TxtEmail);
        TxtContactoEmergencia = (EditText) findViewById(R.id.TxtContactoEmergencia);
        efecha = (TextView) findViewById(R.id.efecha);
        txtEstadoCivil = (TextView) findViewById(R.id.txtEstadoCivil);
        r1 = (RadioButton) findViewById(R.id.radioButtonFemenino);
        r2 = (RadioButton) findViewById(R.id.radioButtonMasculino);
        tv = findViewById(R.id.efecha);
        rgGenero = (RadioGroup) findViewById(R.id.rgGenero);
        btnGuardar = findViewById(R.id.btnGuardar);


        //Lista de opciones del tipo de regimen SS
        spinner1 = (Spinner) findViewById(R.id.spnRegimen);
        String[] opcionesRegimen = {"Contributivo", "Subsidiado", "Excepción", "Especial", "No afiliado"};

        ArrayAdapter<String> adp1 = new ArrayAdapter<String>(IngresarDatos.this, android.R.layout.simple_spinner_dropdown_item, opcionesRegimen);
        spinner1.setAdapter(adp1);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        //Repositorio
        repositorio = new UsuarioRepositorio(this);

        new ConsultaDatosTask().execute();

        Button btnGuardar = (Button) findViewById(R.id.btnGuardar);

        btnGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Guardar();
            }
        });
    }

    private void Guardar() {
        if (txtNombreCompleto.getText().toString().isEmpty()) {
            txtNombreCompleto.setError("Ingrese nombres completos");
        } else {
            txtNombreCompleto.setError(null);
        }
        if (txtNumeroIdentificacion.getText().toString().isEmpty()) {
            txtNumeroIdentificacion.setError("Ingrese documento de identificación");
        } else {
            txtNumeroIdentificacion.setError(null);
        }if (efecha.getText().toString().isEmpty()) {
            efecha.setError("Seleccione la fecha de nacimiento");
        } else {
            efecha.setError(null);
        }if (TxtEdad.getText().toString().isEmpty()) {
            TxtEdad.setError("Ingrese la edad");
        } else {
            TxtEdad.setError(null);
        }if (txtDireccionResidencia.getText().toString().isEmpty()) {
            txtDireccionResidencia.setError("Ingrese la dirección de residencia");
        } else {
            txtDireccionResidencia.setError(null);
        }if (txtCiudadResidencia.getText().toString().isEmpty()) {
            txtCiudadResidencia.setError("Ingrese la ciudad de residencia");
        } else {
            txtCiudadResidencia.setError(null);
        }if (TxtTelefonoContacto.getText().toString().isEmpty()) {
            TxtTelefonoContacto.setError("Ingrese la ciudad de residencia");
        } else {
            TxtTelefonoContacto.setError(null);
        }if (txtOcupacion.getText().toString().isEmpty()) {
            txtOcupacion.setError("Ingrese la ocupación");
        } else {
            txtOcupacion.setError(null);
        }if (txtEPS.getText().toString().isEmpty()) {
            txtEPS.setError("Ingrese la EPS a la cual está afiliado/a");
        } else {
            txtEPS.setError(null);
        }if (txtEstadoCivil.getText().toString().isEmpty()) {
            txtEstadoCivil.setError("Seleccione su estado civil");
        } else {
            txtEstadoCivil.setError(null);
        }if (TxtEmail.getText().toString().isEmpty()) {
            TxtEmail.setError("Ingrese el correo electrónico");
        } else {
            TxtEmail.setError(null);
        }if (TxtContactoEmergencia.getText().toString().isEmpty()) {
            TxtContactoEmergencia.setError("Ingrese contacto en caso de emergencia");
        } else {
            TxtContactoEmergencia.setError(null);


            //VALIDAR LOS DEMAS EDITTEXT
            Intent intent = new Intent(IngresarDatos.this, CrearContrasena.class);
            Bundle bundle = new Bundle();
            bundle.putString("NombreCompleto", txtNombreCompleto.getText().toString());
            bundle.putString("Identificacion", txtNumeroIdentificacion.getText().toString());
            bundle.putString("Edad", TxtEdad.getText().toString());

            intent.putExtras(bundle);

            startActivity(intent);

        }
        //Tarea asincrona
        //Usuario usuario = new Usuario();
        //usuario.setNombres(txtNombreCompleto.getText().toString());
        //GuardarDatosTask tarea = new GuardarDatosTask(usuario);
        //tarea.execute();

        //guardarUsuario(usuario);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void abrirCalendario(View view) {
        Calendar cal = Calendar.getInstance();
        int anio = cal.get(Calendar.YEAR);
        int mes = cal.get(Calendar.MONTH);
        int dia = cal.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog dpd = new DatePickerDialog(IngresarDatos.this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {

                String fecha = dayOfMonth + "/" + month + "/" + year;
                tv.setText(fecha);
            }
        }, anio, mes, dia);
        dpd.show();
    }

    public void mostrarMensaje(String texto) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(texto).setPositiveButton("Aceptar",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                })
                .setNegativeButton("Cancelar",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                            }
                        });
        builder.show();
    }

    //Llamar una tarea asincrona
    private class GuardarDatosTask extends AsyncTask<Void, Void, Boolean> {

        private Usuario usuario;

        public GuardarDatosTask(Usuario usuario) {
            this.usuario = usuario;
        }

        @Override
        protected Boolean doInBackground(Void... voids) {

            //Enviar los datos a un servicio externo o a una base de datos
            repositorio.insert(usuario);
            return true;
        }

        @Override
        protected void onPostExecute(Boolean resultado) {
            if (resultado) {
                mostrarMensaje("Los datos se guardaron exitosamente");

            } else {
                mostrarMensaje("No se pudo guardar los datos");
            }

        }
    }

    //Consultar datos
    private class ConsultaDatosTask extends AsyncTask<Void, Void, Boolean> {

        @Override
        protected Boolean doInBackground(Void... voids) {

            List<Usuario> usuarios = repositorio.getAllUsiarios();
            for (Usuario usuario : usuarios) {
                Log.i("USUARIO", usuario.getNombres());
            }
            return true;
        }

        @Override
        protected void onPostExecute(Boolean resultado) {

        }

    }

    public void guardarUsuario(Usuario usuario) {
        String TAG = "Usuario";
        ServicioUsuario servicioUsuario = UtilidadesApi.getServicioUsuario();
        servicioUsuario.guardar(usuario).enqueue(new Callback<Long>() {
            @Override
            public void onResponse(Call<Long> call, Response<Long> response) {
                if (response.isSuccessful()) {
                    mostrarMensaje(response.body().toString());
                    Log.i(TAG, "Usuario creado. " + response.body().toString());
                }
            }

            @Override
            public void onFailure(Call<Long> call, Throwable t) {
                Log.e(TAG, "No fue guardar los datos.");
            }
        });
    }
}
