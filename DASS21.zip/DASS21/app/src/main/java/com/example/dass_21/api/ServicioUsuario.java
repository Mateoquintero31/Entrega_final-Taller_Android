package com.example.dass_21.api;

import com.example.dass_21.modelos.Usuario;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface ServicioUsuario {

    @POST("usuario")
    Call<Long> guardar(@Body Usuario usuario);
}
