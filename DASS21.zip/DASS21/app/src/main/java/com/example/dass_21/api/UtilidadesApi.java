package com.example.dass_21.api;

public class UtilidadesApi {

    private UtilidadesApi(){}

    public static final String BASE_URL = "http://127.0.0.1/";

    public static ServicioUsuario getServicioUsuario() {
            return RetrofitUsuario.getUsiario(BASE_URL).create(ServicioUsuario.class);
        }
    }

