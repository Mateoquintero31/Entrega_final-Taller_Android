package com.example.dass_21.modelos;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.dass_21.DAO.UsuarioDao;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Database(entities = {Usuario.class}, version = 1, exportSchema = false)
public abstract class UsuarioDataBase extends RoomDatabase{

    //Exposición de DAOs
    public abstract UsuarioDao usuarioDao();

    private static final String DATABASE_NAME = "usuario-db";

    private static UsuarioDataBase INSTANCE;

    private static final int THREADS = 4;

    public static final ExecutorService dbExecutor = Executors.newFixedThreadPool(THREADS);

    public static UsuarioDataBase getInstance(final Context context){
        if (INSTANCE == null){
            synchronized (UsuarioDataBase.class){
                if (INSTANCE == null){
                    INSTANCE = Room.databaseBuilder(
                            context.getApplicationContext(), UsuarioDataBase.class,
                            DATABASE_NAME)
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}
