package com.example.dass_21.Repositorio;

import android.content.Context;

import com.example.dass_21.DAO.UsuarioDao;
import com.example.dass_21.modelos.Usuario;
import com.example.dass_21.modelos.UsuarioDataBase;

import java.util.List;

public class UsuarioRepositorio {
    private final UsuarioDao usuarioDao;

    public UsuarioRepositorio(Context context){
        UsuarioDataBase db = UsuarioDataBase.getInstance(context);
        usuarioDao = db.usuarioDao();
    }

    public List<Usuario> getAllUsiarios(){
        return usuarioDao.getAll();

    }
    public void insert (Usuario usuario){
        UsuarioDataBase.dbExecutor.execute(
                () -> usuarioDao.insert(usuario)
        );
    }
}
