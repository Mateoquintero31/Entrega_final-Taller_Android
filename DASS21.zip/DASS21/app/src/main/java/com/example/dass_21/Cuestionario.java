package com.example.dass_21;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class Cuestionario extends AppCompatActivity {

    private int ids_respuestas1[] = {
            R.id.respuesta1, R.id.respuesta2, R.id.respuesta3, R.id.respuesta4
    };
    private String[] preguntas;
    private int preguntaActual;
    private TextView txtPregunta1, txtTitulo, txtResultadoEstres, txtResultadoDepre, txtResultadoAnsi,
            txtPuntajeCalificacion, txtcomentario;
    private TextView tvNombreCompleto, tvDocumentoIdentidad, tvEdad;
    private RadioGroup group;
    private RadioButton respuesta1, respuesta2, respuesta3, respuesta4;
    private int[] resp;
    private Button btnSiguiente, btnAnterior, btnFinalizar;
    int contadorDepre, contadorAnsi, contadorEstres, resultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cuestionario);

        txtPregunta1 = (TextView) findViewById(R.id.txtPregunta1);
        txtPuntajeCalificacion = (TextView) findViewById(R.id.txtPuntajeCalificacion);
        txtcomentario = (TextView) findViewById(R.id.txtcomentario);
        txtTitulo = (TextView) findViewById(R.id.txtTitulo);
        txtResultadoEstres = (TextView) findViewById(R.id.txtResultadoEstres);
        txtResultadoDepre = (TextView) findViewById(R.id.txtResultadoDepre);
        txtResultadoAnsi = (TextView) findViewById(R.id.txtResultadoAnsi);
        group = (RadioGroup) findViewById(R.id.rgRespuestas);
        btnSiguiente = (Button) findViewById(R.id.btnSiguiente);
        btnFinalizar = (Button) findViewById(R.id.btnFinalizar);
        btnAnterior = (Button) findViewById(R.id.btnAnterior);
        respuesta1 = (RadioButton) findViewById(R.id.respuesta1);
        respuesta2 = (RadioButton) findViewById(R.id.respuesta2);
        respuesta3 = (RadioButton) findViewById(R.id.respuesta3);
        respuesta4 = (RadioButton) findViewById(R.id.respuesta4);
        tvNombreCompleto = (TextView) findViewById(R.id.tvNombreCompleto);
        tvDocumentoIdentidad = (TextView) findViewById(R.id.tvDocumentoIdentidad);
        tvEdad = (TextView) findViewById(R.id.tvEdad);


        preguntas = getResources().getStringArray(R.array.preguntas);
        resp = new int[preguntas.length];
        for (int i = 0; i < resp.length; i++) {
            resp[i] = -1;
        }
        preguntaActual = 0;
        mostrarPregunta();

        txtResultadoAnsi.setVisibility(View.GONE);
        txtResultadoDepre.setVisibility(View.GONE);
        txtResultadoEstres.setVisibility(View.GONE);
        btnFinalizar.setVisibility(View.GONE);


        //Mostrar los datos que ingreso el usuario
        /*Bundle bundle = getIntent().getExtras();
        tvNombreCompleto.setText(bundle.getString("NombreCompleto"));
        tvDocumentoIdentidad.setText(bundle.getString("Identificacion"));
        tvEdad.setText(bundle.getString("Edad"));*/

        btnSiguiente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int id = group.getCheckedRadioButtonId();
                int index = -1;
                for (int i = 0; i < ids_respuestas1.length; i++) {
                    if (ids_respuestas1[i] == id) {
                        index = i;
                    }
                }
                resp[preguntaActual] = index;

                if (respuesta1.isChecked() == false && respuesta2.isChecked() == false && respuesta3.isChecked() == false && respuesta4.isChecked() == false) {
                    Toast.makeText(Cuestionario.this, "Seleccione una opción", Toast.LENGTH_SHORT).show();
                } else if (preguntaActual == 0) {
                    if (respuesta2.isChecked()) {
                        contadorEstres = contadorEstres + 1;
                    } else if (respuesta3.isChecked()) {
                        contadorEstres = contadorEstres + 2;
                    } else if (respuesta4.isChecked()) {
                        contadorEstres = contadorEstres + 3;
                    }
                    preguntaActual++;
                    mostrarPregunta();
                } else if (preguntaActual == 1) {
                    if (respuesta2.isChecked()) {
                        contadorAnsi = contadorAnsi + 1;
                    } else if (respuesta3.isChecked()) {
                        contadorAnsi = contadorAnsi + 2;
                    } else if (respuesta4.isChecked()) {
                        contadorAnsi = contadorAnsi + 3;
                    }
                    preguntaActual++;
                    mostrarPregunta();
                } else if (preguntaActual == 2) {
                    if (respuesta2.isChecked()) {
                        contadorDepre = contadorDepre + 1;
                    } else if (respuesta3.isChecked()) {
                        contadorDepre = contadorDepre + 2;
                    } else if (respuesta4.isChecked()) {
                        contadorDepre = contadorDepre + 3;
                    }
                    preguntaActual++;
                    mostrarPregunta();
                } else if (preguntaActual == 3) {
                    if (respuesta2.isChecked()) {
                        contadorAnsi = contadorAnsi + 1;
                    } else if (respuesta3.isChecked()) {
                        contadorAnsi = contadorAnsi + 2;
                    } else if (respuesta4.isChecked()) {
                        contadorAnsi = contadorAnsi + 3;
                    }
                    preguntaActual++;
                    mostrarPregunta();
                } else if (preguntaActual == 4) {
                    if (respuesta2.isChecked()) {
                        contadorDepre = contadorDepre + 1;
                    } else if (respuesta3.isChecked()) {
                        contadorDepre = contadorDepre + 2;
                    } else if (respuesta4.isChecked()) {
                        contadorDepre = contadorDepre + 3;
                    }
                    preguntaActual++;
                    mostrarPregunta();

                } else if (preguntaActual == 5) {
                    if (respuesta2.isChecked()) {
                        contadorEstres = contadorEstres + 1;
                    } else if (respuesta3.isChecked()) {
                        contadorEstres = contadorEstres + 2;
                    } else if (respuesta4.isChecked()) {
                        contadorEstres = contadorEstres + 3;
                    }
                    preguntaActual++;
                    mostrarPregunta();

                } else if (preguntaActual == 6) {
                    if (respuesta2.isChecked()) {
                        contadorAnsi = contadorAnsi + 1;
                    } else if (respuesta3.isChecked()) {
                        contadorAnsi = contadorAnsi + 2;
                    } else if (respuesta4.isChecked()) {
                        contadorAnsi = contadorAnsi + 3;
                    }
                    preguntaActual++;
                    mostrarPregunta();

                } else if (preguntaActual == 7) {
                    if (respuesta2.isChecked()) {
                        contadorEstres = contadorEstres + 1;
                    } else if (respuesta3.isChecked()) {
                        contadorEstres = contadorEstres + 2;
                    } else if (respuesta4.isChecked()) {
                        contadorEstres = contadorEstres + 3;
                    }
                    preguntaActual++;
                    mostrarPregunta();

                } else if (preguntaActual == 8) {
                    if (respuesta2.isChecked()) {
                        contadorAnsi = contadorAnsi + 1;
                    } else if (respuesta3.isChecked()) {
                        contadorAnsi = contadorAnsi + 2;
                    } else if (respuesta4.isChecked()) {
                        contadorAnsi = contadorAnsi + 3;
                    }
                    preguntaActual++;
                    mostrarPregunta();

                } else if (preguntaActual == 9) {
                    if (respuesta2.isChecked()) {
                        contadorDepre = contadorDepre + 1;
                    } else if (respuesta3.isChecked()) {
                        contadorDepre = contadorDepre + 2;
                    } else if (respuesta4.isChecked()) {
                        contadorDepre = contadorDepre + 3;
                    }
                    preguntaActual++;
                    mostrarPregunta();

                } else if (preguntaActual == 10) {
                    if (respuesta2.isChecked()) {
                        contadorEstres = contadorEstres + 1;
                    } else if (respuesta3.isChecked()) {
                        contadorEstres = contadorEstres + 2;
                    } else if (respuesta4.isChecked()) {
                        contadorEstres = contadorEstres + 3;
                    }
                    preguntaActual++;
                    mostrarPregunta();

                } else if (preguntaActual == 11) {
                    if (respuesta2.isChecked()) {
                        contadorEstres = contadorEstres + 1;
                    } else if (respuesta3.isChecked()) {
                        contadorEstres = contadorEstres + 2;
                    } else if (respuesta4.isChecked()) {
                        contadorEstres = contadorEstres + 3;
                    }
                    preguntaActual++;
                    mostrarPregunta();

                } else if (preguntaActual == 12) {
                    if (respuesta2.isChecked()) {
                        contadorDepre = contadorDepre + 1;
                    } else if (respuesta3.isChecked()) {
                        contadorDepre = contadorDepre + 2;
                    } else if (respuesta4.isChecked()) {
                        contadorDepre = contadorDepre + 3;
                    }
                    preguntaActual++;
                    mostrarPregunta();

                } else if (preguntaActual == 13) {
                    if (respuesta2.isChecked()) {
                        contadorEstres = contadorEstres + 1;
                    } else if (respuesta3.isChecked()) {
                        contadorEstres = contadorEstres + 2;
                    } else if (respuesta4.isChecked()) {
                        contadorEstres = contadorEstres + 3;
                    }
                    preguntaActual++;
                    mostrarPregunta();

                } else if (preguntaActual == 14) {
                    if (respuesta2.isChecked()) {
                        contadorAnsi = contadorAnsi + 1;
                    } else if (respuesta3.isChecked()) {
                        contadorAnsi = contadorAnsi + 2;
                    } else if (respuesta4.isChecked()) {
                        contadorAnsi = contadorAnsi + 3;
                    }
                    preguntaActual++;
                    mostrarPregunta();

                } else if (preguntaActual == 15) {
                    if (respuesta2.isChecked()) {
                        contadorDepre = contadorDepre + 1;
                    } else if (respuesta3.isChecked()) {
                        contadorDepre = contadorDepre + 2;
                    } else if (respuesta4.isChecked()) {
                        contadorDepre = contadorDepre + 3;
                    }
                    preguntaActual++;
                    mostrarPregunta();

                } else if (preguntaActual == 16) {
                    if (respuesta2.isChecked()) {
                        contadorDepre = contadorDepre + 1;
                    } else if (respuesta3.isChecked()) {
                        contadorDepre = contadorDepre + 2;
                    } else if (respuesta4.isChecked()) {
                        contadorDepre = contadorDepre + 3;
                    }
                    preguntaActual++;
                    mostrarPregunta();

                } else if (preguntaActual == 17) {
                    if (respuesta2.isChecked()) {
                        contadorEstres = contadorEstres + 1;
                    } else if (respuesta3.isChecked()) {
                        contadorEstres = contadorEstres + 2;
                    } else if (respuesta4.isChecked()) {
                        contadorEstres = contadorEstres + 3;
                    }
                    preguntaActual++;
                    mostrarPregunta();
                } else if (preguntaActual == 18) {
                    if (respuesta2.isChecked()) {
                        contadorAnsi = contadorAnsi + 1;
                    } else if (respuesta3.isChecked()) {
                        contadorAnsi = contadorAnsi + 2;
                    } else if (respuesta4.isChecked()) {
                        contadorAnsi = contadorAnsi + 3;
                    }
                    preguntaActual++;
                    mostrarPregunta();

                } else if (preguntaActual == 19) {
                    if (respuesta2.isChecked()) {
                        contadorAnsi = contadorAnsi + 1;
                    } else if (respuesta3.isChecked()) {
                        contadorAnsi = contadorAnsi + 2;
                    } else if (respuesta4.isChecked()) {
                        contadorAnsi = contadorAnsi + 3;
                    }
                    preguntaActual++;
                    mostrarPregunta();

                } else if (preguntaActual == 20) {
                    if (respuesta2.isChecked()) {
                        contadorDepre = contadorDepre + 1;
                    } else if (respuesta3.isChecked()) {
                        contadorDepre = contadorDepre + 2;
                    } else if (respuesta4.isChecked()) {
                        contadorDepre = contadorDepre + 3;
                    }
                    preguntaActual++;
                    mostrarPregunta();

                } else if (preguntaActual < preguntas.length - 1) {
                    preguntaActual++;
                    mostrarPregunta();

                }
            }
        });

        btnAnterior.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (preguntaActual > 0) {
                    preguntaActual--;
                    mostrarPregunta();
                }
            }
        });
    }

    private void mostrarPregunta() {
        String q = preguntas[preguntaActual];
        String[] parts = q.split(";");

        group.clearCheck();
        txtPregunta1.setText(parts[0]);
        for (int i = 0; i < ids_respuestas1.length; i++) {
            RadioButton res1 = (RadioButton) findViewById(ids_respuestas1[i]);
            res1.setText(parts[i + 1]);
        }
        if (preguntaActual == 0) {
            btnAnterior.setVisibility(View.GONE);
        } else {
            btnAnterior.setVisibility(View.VISIBLE);
        }
        if (preguntaActual == preguntas.length - 1) {
            btnSiguiente.setText(R.string.terminar);
            txtTitulo.setText("Resultados escala de Depresión Ansiedad Estrés");
            btnAnterior.setVisibility(View.GONE);
            btnSiguiente.setVisibility(View.GONE);
            group.setVisibility(View.GONE);
            txtPregunta1.setVisibility(View.GONE);
            txtcomentario.setVisibility(View.GONE);
            txtPuntajeCalificacion.setVisibility(View.GONE);
            btnFinalizar.setVisibility(View.VISIBLE);

            //Resultados depresión
            txtResultadoDepre.setVisibility(View.VISIBLE);
            if (contadorDepre >= 5 & contadorDepre <= 6) {
                txtResultadoDepre.setText("Puntaje de depresión: " + contadorDepre + "\nGrado de sintomatología: depresión leve");
            } else if (contadorDepre > 6 & contadorDepre <= 10) {
                txtResultadoDepre.setText("Puntaje de depresión: " + contadorDepre + "\nGrado de sintomatología: depresión moderada");
            } else if (contadorDepre > 10 & contadorDepre <= 13) {
                txtResultadoDepre.setText("Puntaje de depresión: " + contadorDepre + "\nGrado de sintomatología: depresión severa");
            } else if (contadorDepre > 13) {
                txtResultadoDepre.setText("Puntaje de depresión: " + contadorDepre + "Grado de sintomatología: depresión extremadamente severa");
            } else {
                txtResultadoDepre.setText("No presenta depresión");

            }
            //Resultados de Ansiedad
            txtResultadoAnsi.setVisibility(View.VISIBLE);
            if (contadorAnsi == 4) {
                txtResultadoAnsi.setText("Puntaje de ansiedad: " + contadorAnsi + "\nGrado de sintomatología: ansiedad leve");
            } else if (contadorAnsi > 4 & contadorAnsi <= 7) {
                txtResultadoAnsi.setText("Puntaje de ansiedad: " + contadorAnsi + "\nGrado de sintomatología: ansiedad moderada");
            } else if (contadorAnsi > 8 & contadorAnsi <= 9) {
                txtResultadoAnsi.setText("Puntaje de ansiedad: " + contadorAnsi + "\nGrado de sintomatología: ansiedad severa");
            } else if (contadorAnsi > 9) {
                txtResultadoAnsi.setText("Puntaje de ansiedad: " + contadorAnsi + "Grado de sintomatología: ansiedad extremadamente severa");
            } else {
                txtResultadoAnsi.setText("No presenta ansiedad");
            }
            //Resultados de Estres
            txtResultadoEstres.setVisibility(View.VISIBLE);
            if (contadorEstres >7 & contadorEstres <= 9) {
                txtResultadoEstres.setText("Puntaje de estrés: " + contadorEstres + "\nGrado de sintomatología: estrés leve");
            } else if (contadorEstres > 9 & contadorEstres <= 12) {
                txtResultadoEstres.setText("Puntaje de estrés: " + contadorEstres + "\nGrado de sintomatología: estrés moderado");
            } else if (contadorEstres > 12 & contadorEstres <= 16) {
                txtResultadoEstres.setText("Puntaje de estrés: " + contadorEstres + "\nGrado de sintomatología: estrés severo");
            } else if (contadorEstres > 16) {
                txtResultadoEstres.setText("Puntaje de estrés: " + contadorEstres + "Grado de sintomatología: estrés extremadamente severo");
            } else {
                txtResultadoEstres.setText("No presenta estrés");
            }

            //Intent resultado= new Intent(this,MainActivity.class );
            //startActivity(resultado);

        } else {
            btnSiguiente.setText(R.string.Siguiente);
        }
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);

    }

}