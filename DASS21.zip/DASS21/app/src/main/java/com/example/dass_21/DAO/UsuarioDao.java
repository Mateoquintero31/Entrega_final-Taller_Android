package com.example.dass_21.DAO;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.example.dass_21.modelos.Usuario;

import java.util.List;

@Dao
public interface UsuarioDao {
    @Query("SELECT * FROM usuarios")
    List<Usuario> getAll();

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insert (Usuario usuario);
}
